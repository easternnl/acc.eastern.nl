﻿# load the modules
Import-Module "$(Split-Path -parent $PSCommandPath)\Test-Availability.psm1" -Force
Import-Module "$(Split-Path -parent $PSCommandPath)\iTextSharp.psm1" -Force

# -------------------------------------------
# configure variabeles

$testdocument = "$(Split-Path -parent $PSCommandPath)\testdocument.docx"
$testworkbook = "$(Split-Path -parent $PSCommandPath)\testworkbook.xlsx"
$printer = "Bullzip PDF Printer"
$appvcontentstore = "C:\AppV"

# -------------------------------------------

# Stop if an error has occured, will be handled by the try/catch
$ErrorActionPreference = "Stop"

# Verbose messages on
#$VerbosePreference = "Continue"
# wait time between the steps
$sleepseconds = 1
# temporary path to log the output to
$outputfile = "$($env:temp)\test.su"
if (Test-Path $outputfile) { rm $outputfile }



try {

    # Start Outlook 
        $transactionname = "Outlook - Start"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $outlook = new-object -com "Outlook.Application"
            #$outlook.visible = $true
            $namespace = $outlook.GetNamespace("MAPI")
            $folder = $namespace.GetDefaultFolder(16)
            $folder.Display()
            } )

        # Write email
        # (not sending an email because that is blocked by default in Outlook)
        $transactionname = "Outlook - Write message in draft"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $mail = $outlook.CreateItem(0)
            $mail.Subject = "$(Get-Date -format "yyyy-MM-dd HH:mm:ss") VDI Test Script"
            $mail.To = "user@domain.com"
            $mail.Body = "Testing the VDI functionality with a script"
            $mail.save()
            } )

        # Close Outlook 
        $transactionname = "Outlook - Exit"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $outlook.Quit()
            } )
            
    # Internet Explorer - eastern.nl
        $transactionname = "Internet Explorer - Start"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $ie = new-object -com "InternetExplorer.Application"
            $ie.visible = $true
    
            Set-ForegroundWindow "Internet Explorer"
            } )
    
        # navigate
        $transactionname = "Internet Explorer - www.eastern.nl"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $ie.Navigate("http://www.eastern.nl/")
    
            # wait until the page is ready, all parameters okay and the text Erik van Oost is inside the document
            Wait-InternetExplorer -ie $ie -text "Erik van Oost"
            } )
        
        $transactionname = "Internet Explorer - Quit"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            # Internet Explorer Exit
            $ie.quit()
            } )
	
        # Word
        $transactionname = "Word - Start"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $word=new-object -ComObject "Word.Application"
            $word.visible = $true
            } )
    
        # Document open 
        $transactionname = "Word - Open testfile"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $doc = $word.Documents.Open($testdocument)
            } )

        # Document saven op temp
        $transactionname = "Word - Save testfile"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $filename = "$($env:temp)\test.docx"
            $file_formatcode = 12

            if (Test-Path filename) { rm $filename -Force -ErrorAction SilentlyContinue }
            $doc.SaveAs([ref]$filename, [ref]$file_formatcode)
        } )

        $transactionname = "Word - Print preview"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $doc.PrintPreview()        
            } )

        <#
        $transactionname = "Word - Print"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            # set active printer             
            $word.activeprinter = $printer
            
            # Document afdrukken
            $doc.PrintOut([ref]$false)
            } )
        #>

        $transactionname = "Word - Quit"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            # Close document
            $doc.Close()
            # Exit Word
            $word.Quit()
                } )

    # Start Excel 
        $transactionname = "Excel - start"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $excel = new-object -comobject Excel.Application
            $excel.visible = $True
            } )
    
        # Open workbook
        $transactionname = "Excel - Open testfile"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $wb = $excel.Workbooks.Open($testworkbook)
            } )
    
        # Save workbook
        $transactionname = "Excel - Save testfile"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $filename = "$($env:temp)\test.xlsx"        
            $excel.displayalerts = $false
            $wb.SaveAs($filename)
            } )
    	
    # Close Excel
        $transactionname = "Excel - Quit"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $excel.quit()
        } )

    # Visit AppV Content Store
        $transactionname = "AppV - ContentStore"
        Write-Transaction -transactionname $transactionname -sleepseconds $sleepseconds -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $app = Start-Process cmd.exe -PassThru -ArgumentList " /k dir `"$($appvcontentstore)`" /ogneds" -WorkingDirectory "C:\" 

            } )
        
            # Content store Sluiten
            Stop-Process -Id $app.Id 

    # AppV Application
    # %ALLUSERSPROFILE%\Microsoft\AppV\Client\Integration\4C39F850-61B3-4ED5-95E0-0F21C0B6D0BB\Root\DLS.exe
        $transactionname = "AppV Application Dymo Label Writer"
        Write-Transaction -transactionname $transactionname -sleepseconds 5 -outputfile $outputfile -screenshot $true -measured ( Measure-Command {
            $app = Start-Process  C:\ProgramData\Microsoft\AppV\Client\Integration\4C39F850-61B3-4ED5-95E0-0F21C0B6D0BB\Root\DLS.exe -PassThru 

            } )
        
            # Content store Sluiten
            Stop-Process -Id $app.Id 

   

    # End of test
        $result = Show-PopUp -Message "Test ended sucessfully" -Title "Test Automation" -ButtonSet OK -IconType Information
}
catch
{
    # log if an error occurs, including a screenshot with the error
    $Error

    Write-Transaction -transactionname "ERROR $transactionname" -sleepseconds 0 -outputfile $outputfile -screenshot $true -measured ( Measure-Command { sleep -Milliseconds 100 } )

    $result = Show-PopUp -Message "Test ended with error" -Title "Test Automation" -ButtonSet OK -IconType Exclamation
}

# Ask for conversion to PDF
    $result = Show-PopUp -Message "Do you want to write the results to a PDF file?" -Title "PDF file" -ButtonSet YNC -IconType Question

    if ($result -eq 6)
    {
        # when in an Citrix Session log some information about Citrix
        $sessioninfo = (Get-ItemProperty -Path HKLM:SOFTWARE\Citrix\ICA\Session -ErrorAction SilentlyContinue )
        $outputpdf = (Get-FileName -defaultFileName "$(get-date ((ls $outputfile).CreationTime) -Format "yyyy-MM-dd HHmmss") Workplace and VDI test-automation with PowerShell.pdf" )        
        $message = "VDI Desktop Image testscript run on $(get-date -Format "yyyy-MM-dd HH:mm"). `n`nOutput PDF: $(split-path $outputpdf -leaf)`nComputername: $($env:computername)`n"
		# when in an Citrix Session log some information about Citrix
		if ($sessioninfo -ne $null)
		{
			$message += "Clientaddress: $($sessioninfo.clientaddress) `nClientname: $($sessioninfo.clientname) `nClientversion: $($sessioninfo.clientversion)"
		}
		$message += "`n`n"
        convert-su-to-pdf -inputsu $outputfile -outputpdf $outputpdf -title "Desktop Image functional Script" -message $message
    }

# ask for logoff
    $result = Show-PopUp -Message "Do you want to logoff?" -Title "Logoff" -ButtonSet YNC -IconType Question

    if ($result -eq 6)
    {
        start-process logoff
    }