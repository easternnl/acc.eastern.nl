﻿[CmdletBinding()][OutputType([int])]Param(
    [parameter(Mandatory=$true, ValueFromPipeLine=$true)][Alias("Msg")][string]$Message,
    [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("Ttl")][string]$Title = $null,
    [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("Duration")][int]$TimeOut = 0,
    [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("But","BS")][ValidateSet( "OK", "OC", "AIR", "YNC" , "YN" , "RC")][string]$ButtonSet = "OK",
    [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("ICO")][ValidateSet( "None", "Critical", "Question", "Exclamation" , "Information" )][string]$IconType = "None"
     )

Function Show-PopUp{
    [CmdletBinding()][OutputType([int])]Param(
        [parameter(Mandatory=$true, ValueFromPipeLine=$true)][Alias("Msg")][string]$Message,
        [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("Ttl")][string]$Title = $null,
        [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("Duration")][int]$TimeOut = 0,
        [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("But","BS")][ValidateSet( "OK", "OC", "AIR", "YNC" , "YN" , "RC")][string]$ButtonSet = "OK",
        [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("ICO")][ValidateSet( "None", "Critical", "Question", "Exclamation" , "Information" )][string]$IconType = "None"
         )
    
    $ButtonSets = "OK", "OC", "AIR", "YNC" , "YN" , "RC"
    $IconTypes  = "None", "Critical", "Question", "Exclamation" , "Information"
    $IconVals = 0,16,32,48,64
    if((Get-Host).Version.Major -ge 3){
        $Button   = $ButtonSets.IndexOf($ButtonSet)
        $Icon     = $IconVals[$IconTypes.IndexOf($IconType)]
        }
    else{
        $ButtonSets|ForEach-Object -Begin{$Button = 0;$idx=0} -Process{ if($_.Equals($ButtonSet)){$Button = $idx           };$idx++ }
        $IconTypes |ForEach-Object -Begin{$Icon   = 0;$idx=0} -Process{ if($_.Equals($IconType) ){$Icon   = $IconVals[$idx]};$idx++ }
        }
    $objShell = New-Object -com "Wscript.Shell"
    $objShell.Popup($Message,$TimeOut,$Title,$Button+$Icon)

    <#
        .SYNOPSIS
            Creates a Timed Message Popup Dialog Box.

        .DESCRIPTION
            Creates a Timed Message Popup Dialog Box.

        .OUTPUTS
            The Value of the Button Selected or -1 if the Popup Times Out.
           
            Values:
                -1 Timeout  
                 1  OK
                 2  Cancel
                 3  Abort
                 4  Retry
                 5  Ignore
                 6  Yes
                 7  No

        .PARAMETER Message
            [string] The Message to display.

        .PARAMETER Title
            [string] The MessageBox Title.

        .PARAMETER TimeOut
            [int]   The Timeout Value of the MessageBox in seconds. 
                    When the Timeout is reached the MessageBox closes and returns a value of -1.
                    The Default is 0 - No Timeout.

        .PARAMETER ButtonSet
            [string] The Buttons to be Displayed in the MessageBox. 

                     Values:
                        Value     Buttons
                        OK        OK                   - This is the Default          
                        OC        OK Cancel          
                        AIR       Abort Ignore Retry
                        YNC       Yes No Cancel     
                        YN        Yes No             
                        RC        Retry Cancel       

        .PARAMETER IconType
            [string] The Icon to be Displayed in the MessageBox. 

                     Values:
                        None      - This is the Default
                        Critical    
                        Question    
                        Exclamation 
                        Information 
            
        .EXAMPLE
            $RetVal = Show-PopUp -Message "Data Trucking Company" -Title "Popup Test" -TimeOut 5 -ButtonSet YNC -Icon Exclamation

        .NOTES
            FunctionName : Show-PopUp
            Created by   : Data Trucking Company
            Date Coded   : 06/25/2012 16:55:46

        .LINK
            
     #>

}

function Write-Transaction() {
  
    param ( [Parameter(Mandatory =$true, ValueFromPipelineByPropertyName=$true ,HelpMessage= "Name of the transaction", ValueFromPipeline=$true )]
            [string] $transactionname,          
            [Parameter(Mandatory =$true, ValueFromPipelineByPropertyName=$true ,HelpMessage= "Data collected with Measure-Command", ValueFromPipeline=$true )]
            $measured,
            [Parameter(Mandatory =$false, ValueFromPipelineByPropertyName=$true ,HelpMessage= "File to write output to" ,ValueFromPipeline= $true)]
            $outputfile="" ,
            [Parameter(Mandatory =$false, ValueFromPipelineByPropertyName=$true ,HelpMessage= "Sleep seconds between transactions" ,ValueFromPipeline= $true)]
              $sleepseconds=0,
            [Parameter(Mandatory =$false, ValueFromPipelineByPropertyName=$true ,HelpMessage= "Take a screenshot after the action is performed" ,ValueFromPipeline= $true)]
              $screenshot=$false
           )

    # calculate start and stoptime
    $stoptime = ([DateTime ]::Now)
    $starttime = $stoptime
    $starttime = $starttime.AddMilliseconds(-$measured.TotalMilliseconds)

    # wait xx seconds
    if ($sleepseconds -ne 0)
    {
        sleep $sleepseconds
    }

    # process screenshot if needed
    if ($screenshot -eq $true)
    {
        # boxcutter needed
        if (Test-Path ".\boxcutter.exe") { $boxcutter = ".\boxcutter.exe" }
        if (Test-Path "$(Get-ScriptDirectory)\boxcutter.exe") { $boxcutter = "$(Get-ScriptDirectory)\boxcutter.exe" }

        #Write-Verbose "boxcutter = $boxcutter"
        #Write-Verbose $(Get-ScriptDirectory)

        if ($boxcutter -ne $null)
        {
            $screenshotfile = "$env:temp\$(Get-Date $starttime -format "yyyy-MM-dd") $(Get-Date $starttime -format "HH.mm.ss").$($starttime.Millisecond) $transactionname.png"
            #$screenshotfile = $screenshotfile -creplace '^[^\\]*\\', ''
            Write-Verbose "Saving screenshot: $boxcutter -f `"$screenshotfile`" "
            
            $app = Start-Process  $boxcutter -argumentlist " -f `"$screenshotfile`"" -Wait       
        }
        else
        {
            Write-Error "Cannot find boxcutter.exe for taking screenshot"
        }
    }

    if ($outputfile -ne "")
    {
        Write-Output  "$(Get-Date $starttime -format "yyyy-MM-dd")`t$(Get-Date $starttime -format "HH:mm:ss").$($starttime.Millisecond)`t$( Get-Date $stoptime -format "HH:mm:ss").$($stoptime.Millisecond)`t$($measured. TotalSeconds)`t$( $transactionname)`t$screenshotfile"   | Out-File -FilePath $outputfile -Append  -Encoding "UTF8"
    }
    write-host "$(Get-Date $starttime -format "yyyy-MM-dd")`t$(Get-Date $starttime -format "HH:mm:ss").$($starttime.Millisecond)`t$(Get-Date $stoptime -format "HH:mm:ss").$($stoptime.Millisecond)`t$($measured. TotalSeconds)`t$( $transactionname)`t$screenshotfile"


}


Function Test-SQLServer
{
<#
   .Synopsis 
    Test if the given server accepts an SQL connection
   .DESCRIPTION
    Test if the given server accepts an SQL connection
   .PARAMETER Server
    The server tot test    
   .Link
    http://www.eastern.nl
 #>

 param ([string]$server)

    $connectionString = "Data Source=$server;Integrated Security=true;Initial Catalog=master;Connect Timeout=3;"
    $sqlConn = new-object ("Data.SqlClient.SqlConnection") $connectionString
    $sqlConn.Open()

    If ($sqlConn.State -eq 'Open')
    {
        log  -level "INFO" -identity "$server" -message "SQL OK"
    }
    else
    {
        $state = $sqlConn.State
        if ($state -eq $null) { $state = "unknown" }
        log -level "ERROR" -identity $server -message "SQL NOK - $state " 
    }
}

Function Test-Webrequest
{
<#
   .Synopsis 
    Test if a given URL has the expected result code.
   .DESCRIPTION
    Test if a webserver is operating and functioning well. It gives a return code and this will be handled as expected. An exception will be trapped.
   .PARAMETER Url
    The URL to visi
   .PARAMETER ExcpetedResult
    What should the webserver respond (200 OK, 403 UnAuthorized etc)
   .PARAMETER TrustAllCertsPolicy
    What to do if the secure webserver is working with an un
   .EXAMPLE
    
   .Link
    http://www.eastern.nl
 #>
 
param(
        [Parameter(ValueFromPipeline = $true,ValueFromPipelineByPropertyName = $true)]
        [string]$url,
        [long]$expectedresult
    )

 
# Accept all certificates including unsigned and wrong commonnames (for testing purpose)
if (-not ("TrustAllCertsPolicy2" -as [type])) {
add-type @"
   using System.Net;
   using System.Security.Cryptography.X509Certificates;
   public class TrustAllCertsPolicy : ICertificatePolicy {
       public bool CheckValidationResult(
           ServicePoint srvPoint, X509Certificate certificate,
           WebRequest request, int certificateProblem) {
           return true;
       }
   }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}
 
try {
    $response = Invoke-WebRequest $url -UseBasicParsing -TimeoutSec .5 -UseDefaultCredentials
 
    if ($response.StatusDescription,$response.StatusCode -eq $expectedresult)
    {
        # expected result
        log  -identity $url -message "$($response.StatusDescription,$response.StatusCode) " -level "INFO"
    }
    else
    {
        # unexpected, but still a result
        log  -identity $url -message "$($response.StatusDescription,$response.StatusCode) " -level "ERROR"
    }    
}
catch
{
    # unexpected, error handling procedure
    log  -identity $url -message "ERROR: $($_.Exception.Response.StatusCode.Value__) " -level "ERROR"  
}
 
}
 
Function Test-UNCPath
{
param(
        [Parameter(ValueFromPipeline = $true,ValueFromPipelineByPropertyName = $true)]
        [string]$unc
    )

    if (Test-Path $unc)
    {
        log  -identity $unc -message "OK" -level "INFO"
    }
    else
    {
        log  -identity $unc -message "NOK" -level "ERROR"
    }
        

}
 
Function Test-Services
{
 
param(
        [Parameter(ValueFromPipeline = $true,ValueFromPipelineByPropertyName = $true)]
        [string]$computername,
        [string]$servicelist,
        [string]$expectedresult
    )
 
    $services_mandatory = $servicelist.Split(",")
 
    # Old and slow: $services = Get-Service -ComputerName $computername
    $services = gwmi win32_service -ComputerName $computername
 
    foreach ($service_mandatory in $services_mandatory)
    {
        if ($services | where { $_.displayname -ieq $service_mandatory } | where { $_.State -ieq $expectedresult} )
        {
            # service running
            log  -identity $computername -message "$service_mandatory is running" -level "INFO"
        }
        else
        {
            # service other status
            $state = ($services | where { $_.displayname -ieq $service_mandatory }).state
            If ($state -eq $null) { $state = "unknown" }
            log  -identity $computername -message "$service_mandatory is $state " -level "ERROR"          
           
        }
    }
   
 
}

function Test-Ping
{
param ([string]$HostName, [int32]$Requests = 1, [int32]$timeout = 300)
   
      for ($i = 1; $i -le $Requests; $i ++)
      {
            $Result = Get-WmiObject -Class Win32_PingStatus -ComputerName . -Filter "Address='$HostName' and Timeout=$timeout"
           
            If ($Result.StatusCode -ne 0)
            {               
                Log  -identity $hostname -message "ping failed" -level "ERROR"          
                return $false
            }
      }
      Log  -identity $hostname -message "ping successful" -level "INFO"
      return $TRUE
}
 
function Test-Port
{
    Param(
        [parameter(ParameterSetName='ComputerName', Position=0)]
        [string]
        $ComputerName,
 
        [parameter(ParameterSetName='IP', Position=0)]
        [System.Net.IPAddress]
        $IPAddress,
 
        [parameter(Mandatory=$true , Position=1)]
        [int]
        $Port,
 
        [parameter(Mandatory=$true, Position=2)]
        [ValidateSet("TCP", "UDP")]
        [string]
        $Protocol
        )
 
    $RemoteServer = If ([string]::IsNullOrEmpty($ComputerName)) {$IPAddress} Else {$ComputerName};


 
    If ($Protocol -eq 'TCP')
    {
        $test = New-Object System.Net.Sockets.TcpClient;
        
        Try
        {            
            $null = $test.BeginConnect($RemoteServer, $Port, $null, $null);
    

             for ($i=1; $i -le 10; $i++)
             {

                if ($test.Connected -eq $true)
                {
                    break;
                }
                else
                {
                    sleep -Milliseconds 1
                }
            }
            if ($test.Connected -eq $true)
            {
                #Write-Host "Connected in $i trips"
                Log  -identity $RemoteServer -message "$Port Connection successful" -level "INFO"            
                return $true;
            }
            else
            {
                #Write-Host "Failed in $i trips"
                Log  -identity $RemoteServer -message "$Port Connection failed" -level "ERROR"          
                return $false
            }       
        }
        Catch
        {
            # Log -logtext "$($RemoteServer):$Port Connection failed" -level "ERROR"          
            Log  -identity $remoteServer -message "$Port Connection failed" -level "ERROR"          
            return $false;
        }
        Finally
        {
            $test.Dispose();
        }
    }
 
    If ($Protocol -eq 'UDP')
    {
        Write-Host "UDP port test functionality currently not available."
       
        #$test = New-Object System.Net.Sockets.UdpClient;
        #Try
        #{
            #Write-Host "Connecting to "$RemoteServer":"$Port" (UDP)..";
            #$test.Connect($RemoteServer, $Port);
            #Write-Host "Connection successful";
        #}
        #Catch
        #{
            #Write-Host "Connection failed";
        #}
        #Finally
        #{
            #$test.Dispose();
        #}
       
    }
}
 
Function Log
{
    Param($level, $identity, $message)

    # output:
    #
    # [datetime] [level] [identity] [message]
   
    $logline = "$(Get-Date -format "yyyy-MM-dd HH:mm:ss")`t$level`t$identity`t$message"    
    #Write-Host $outputfile  
 
    If ($level -eq "INFO")
    {
        # the message send is a INFO message
        If ($reporting -eq "INFO")
        {
            if ($outputfile -ne "")
            {
                Write-Output $logline | Out-File -FilePath $outputfile -Append  -Encoding "UTF8"
            }
            Write-Host $logline
        }
    }
    
    If ($level -eq "ERROR")
    {
        # always log errors
        if ($outputfile -ne "")
        {
            Write-Output $logline | Out-File -FilePath $outputfile -Append  -Encoding "UTF8"
        }
        Write-Host $logline
    }

    if ($level -eq "SECTION")
    {
        # always log section
        if ($outputfile -ne "")
        {
            Write-Output $logline | Out-File -FilePath $outputfile -Append  -Encoding "UTF8"
        }
        Write-Host $logline
    }
 
}

Function Set-ForegroundWindow
{
<#

  .Synopsis  
    Brings a given application to the foreground.
   .Description
    Brings a given application to the foreground.
   .Example
    Set-ForegroundWindow -ApplicationName "Internet Explorer"
    Brings Internet Explorer to the foreground
   .Parameter ApplicationName
    The application name
   .Notes
    NAME:  Set-ForegroundWindow
    AUTHOR: Erik van Oost
    LASTEDIT: 7-8-2015
    KEYWORDS:
   .Version 
    1.0
   .Link
    http://www.eastern.nl
 #Requires -Version 2.0
 #>
    param ( [Parameter(Mandatory=$true, ValueFromPipelineByPropertyName=$true ,HelpMessage= "Name of the transaction", ValueFromPipeline=$true )][string]$ApplicationName)

    add-type -AssemblyName microsoft.VisualBasic
    [Microsoft.VisualBasic.Interaction]::AppActivate($applicationname)
}

Function Get-ScriptDirectory
{ 
    return Split-Path -parent $PSCommandPath
}

Function Wait-InternetExplorer
{
<#

  .Synopsis  
    Waits for the Internet Explorer while browsing a page
   .Description
    Waits for the Internet Explorer while browsing a page. Normally the automation objects closes too fast. This will wait for the Internet Explorer to finish loading the complete page.
   .Example
    WaitForInternetExplorer -ie $ie -text "Erik van Oost"
    Checks the $ie object and scans the loaded page for having the text Erik van Oost inside
   .Parameter ie
    The Internet Explorer object
   .Parameter text
    The text to check in the website for
   .Notes
    NAME:  Wait-InternetExplorer
    AUTHOR: Erik van Oost
    LASTEDIT: 14-8-2015
    KEYWORDS:
   .Version 
    1.0
   .Link
    http://www.eastern.nl
 #>

    param ($ie, $text)

    Do
    {
        write-verbose "Internet Explorer - Check if page is initialized - [string]::IsNullOrEmpty(`$ie.Document.body.innerHTML) $([string]::IsNullOrEmpty($ie.Document.body.innerHTML))"
        sleep -Milliseconds 100 
    }
    While ([string]::IsNullOrEmpty($ie.Document.body.innerHTML) -eq $true)
    
    Do
    {
        write-verbose "Internet Explorer - Check if page has given text - `$ie.Document.body.innerHTML.Contains(`"$($text)`") $($ie.Document.body.innerHTML.Contains($text))"
        sleep -Milliseconds 100 
    }
    while ($ie.Document.body.innerHTML.Contains($text) -eq $false)

    Do
    { 
        sleep -Milliseconds 100 
        write-verbose "Internet Explorer - Check if page is not busy anymore - ie.Busy: $($ie.Busy)"        
    }
    While ($ie.Busy -eq $true) 

    Do
    { 
        Sleep -Milliseconds 100 
        write-verbose "Internet Explorer - Check if page is ready - ie.ReadyState: $($ie.ReadyState)"        
    }
    While ($ie.readystate -ne 4) 

    Sleep -Milliseconds 500
}

Function Convert-Status-to-PDF
{
    Param($outputpdf, $inputstatus, $title, $message)

    # Remove old output file
    if (Test-Path $outputpdf) { rm $outputpdf }

    # create a new PDF document
    $pdf = New-Object iTextSharp.text.Document
    $null = PDF-Create -Document $pdf -File $outputpdf -TopMargin 40 -BottomMargin 40 -LeftMargin 40 -RightMargin 40 -Author "Erik van Oost"

    $pdf.Open()

    # Write title and summary
    $null = PDF-Add-Title -Document $pdf -Text "Backend monitor testscript" -Color "red" -Centered
    $null = PDF-Add-Text -Document $pdf -Text $message

    # Create the list with errors
    $null = PDF-Add-Title -Document $pdf -Text "Summary with errors" 
    $null = PDF-Add-Text -Document $pdf -Text "During the test the following errors have occured."
    
        $transactions = gc $inputstatus
        $section = ""
        $dataset = @()

         # configure headerrow
        $cell = New-Object iTextSharp.text.pdf.PdfPCell
        $cell.BackgroundColor = [iTextSharp.text.BaseColor]::"LIGHT_GRAY"            
        $cell.Phrase = "Section"
        $null = $dataset += $cell

        $cell = New-Object iTextSharp.text.pdf.PdfPCell
        $cell.BackgroundColor = [iTextSharp.text.BaseColor]::"LIGHT_GRAY"            
        $cell.Phrase = "Server"
        $null = $dataset += $cell
            
        $cell = New-Object iTextSharp.text.pdf.PdfPCell
        $cell.BackgroundColor = [iTextSharp.text.BaseColor]::"LIGHT_GRAY"            
        $cell.Phrase = "Status"
        $null = $dataset += $cell

        foreach ($transaction in $transactions)
        {
            ($date, $level, $identity, $message) = $transaction.Split("`t")
    
            #Write-Host $date, $level, $identity, $message  
    
            if ($level -eq "SECTION")
            {
                # section begin, begin new section
                $section = $message.Replace("Scanning","")

            }
            # convert the data into the table
            if ($level -eq "ERROR")
            {
                # add the data to the dataset
                $dataset += $section
                $dataset += $identity
                $dataset += $message
                    #write-host "$section $identity $message"
            }  
    

        }

        # all errors collected, add the data to the document
        $null = PDF-Add-Table -Document $pdf -Dataset $dataset -Cols 3 -Centered

    # next section with detail information
    $null = PDF-Add-Title -Document $pdf -Text "Detail overview" 
    $null = PDF-Add-Text -Document $pdf -Text "Next chapter show all the detail information."

        # Read the transactions from the file
        $transactions = gc $inputstatus
        $section = ""

        foreach ($transaction in $transactions)
        {
            ($date, $level, $identity, $message) = $transaction.Split("`t")
    
            #Write-Host $date, $level, $identity, $message  
    
            if ($level -eq "SECTION")
            {
                # section begin, lets end previous section
                if ($section -ne "")
                {
                    # defined, log the data
                    $null = PDF-Add-Table -Document $pdf -Dataset $dataset -Cols 2 -Centered
                }

                # begin new section
                $section = $message
        
                Write-Host "Converting $section"
                $null = $pdf.NewPage()
                $null = PDF-Add-Title -Document $pdf -Text "$section" -FontSize 14

                # clean the dataset
                $dataset = @()

                # configure headerrow
                $cell = New-Object iTextSharp.text.pdf.PdfPCell
                $cell.BackgroundColor = [iTextSharp.text.BaseColor]::"LIGHT_GRAY"            
                $cell.Phrase = "Server"
                $null = $dataset += $cell
            
                $cell = New-Object iTextSharp.text.pdf.PdfPCell
                $cell.BackgroundColor = [iTextSharp.text.BaseColor]::"LIGHT_GRAY"            
                $cell.Phrase = "Status"
                $null = $dataset += $cell
            }
            else
            {
        
                # convert the data into the table
                if ($level -eq "ERROR")
                {
                    # add the data in color red            
                    $cell = New-Object iTextSharp.text.pdf.PdfPCell
                    $cell.BackgroundColor = [iTextSharp.text.BaseColor]::"red"
            
                    $cell.Phrase = $identity
                    $null = $dataset += $cell

                    $cell = New-Object iTextSharp.text.pdf.PdfPCell
                    $cell.BackgroundColor = [iTextSharp.text.BaseColor]::"red"

                    $cell.Phrase = $message            
                    $null = $dataset += $cell
                }
                elseif ($level -eq "INFO")
                {
                    # add the data just as is
                    $dataset += $identity
                    $dataset += $message
                }
                elseif ($level -eq "WARN")
                {
                    # add the data just as is
                    $dataset += $identity
                    $dataset += $message
                }

            }  
        }

        # Add the latest table to the document, this will not be handled in the foreach loop because it terminates before
        $null = PDF-Add-Table -Document $pdf -Dataset $dataset -Cols 2 -Centered

    # Close the document
    $pdf.Close()

    # Open the output file
    start-process $outputpdf
}

Function Convert-SU-to-PDF 
{
    Param($outputpdf, $inputsu, $title, $message)

    # Remove old output file
    if (Test-Path $outputpdf) { rm $outputpdf }

    # create a new PDF document
    $pdf = New-Object iTextSharp.text.Document
    $null = PDF-Create -Document $pdf -File $outputpdf -TopMargin 40 -BottomMargin 40 -LeftMargin 40 -RightMargin 40 -Author "Erik van Oost" 
    $pdf.Open()

    $null = PDF-Add-Title -Document $pdf -Text $title -Color "red" -Centered
    $null = PDF-Add-Text -Document $pdf -Text $message
    
    # Read the transactions from the file
    $transactions = gc $inputsu

    foreach ($transaction in $transactions)
    {
        ($date, $starttime, $stoptime, $duration, $description, $imgfile) = $transaction.Split("`t")
    
        # load the image which is referenced
        [iTextSharp.text.Image]$img = [iTextSharp.text.Image]::GetInstance($imgfile)
        $img.ScaleAbsolute(800,600)
    
        # add the text and the image to the table
        $null = PDF-Add-Table -Document $pdf -Dataset @("Transaction", "$description", "Date", "$date", "Start time", "$starttime", "Stop time", "$stoptime", "Duration", "$duration seconds", "Result", $img) -Cols 2 -Centered
    }

    # close the pdf file
    $pdf.Close()

    # open the file for reading in the default viewer
    start-process $outputpdf
}
 

Function Get-FileName($initialDirectory , $defaultFileName )
{  
    [System.Reflection.Assembly ]::LoadWithPartialName("System.windows.forms" ) | Out-Null

    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog = New-Object System.Windows.Forms.SaveFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    $openfileDialog.FileName = $defaultFileName
    $OpenFileDialog.filter = "All files (*.*)| *.*"
    $OpenFileDialog.ShowDialog() | Out-Null
    $OpenFileDialog.filename
} 
